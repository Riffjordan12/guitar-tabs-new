import { Type } from '@angular/core';
import { UsersContainer } from './users.container';

export const containers: Type<any>[] = [
  UsersContainer,
];
