import { Routes } from '@angular/router';
import { UsersContainer } from './containers/users.container';

export const routes: Routes = [
  {
    path: '',
    component: UsersContainer,
  }
];
