import { Type } from '@angular/core';
import { UserComponent } from './user.component';

export const components: Type<any>[] = [
  UserComponent,
];
