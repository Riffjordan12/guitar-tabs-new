import { Type } from '@angular/core';
import { UsersPickerModal } from './users-picker.modal';

export const modals: Type<any>[] = [
  UsersPickerModal,
];
