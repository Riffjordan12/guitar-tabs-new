# AngularUsersRxjsExample

### How use

1. [Online Demo](https://korniychuk.github.io/angular-users-rxjs-example)
2. Local `npm run build`, go to `localhost:4200`
3. For git pages `npm run build:git-pages`
