# Arquitetura e Projeto de Sistemas (APS-2018-2)

## Plano

Para saber o tema da disciplina, conteúdo, métodos de avaliação e mais, acesse o [Plano da Disciplina](https://github.com/aps-2018-2/sobre/blob/master/PLANO.md)

## Contas

É preciso ter uma conta no [GitHub](https://github.com/join) e ingressar no grupo do Slack em <https://aps-2018-2.slack.com>. O primeiro será usado para subir as atividades e o segundo para comunicação. Há um aplicativo do Slack disponível para [Android](https://play.google.com/store/apps/details?id=com.Slack&hl=pt_BR) e [iOS](https://itunes.apple.com/br/app/slack/id618783545).

Use o GitHub para subir seus códigos; ou considere carregar um Pen Drive e/ou manter um Cloud Drive como o Dropbox.

## Softwares

Para desenvolver o projeto será usada a IDE Eclipse for Java EE <http://www.eclipse.org/downloads/packages/eclipse-ide-java-ee-developers/photonr>. Ademais, é necessário apenas o JDK8+, como em POO.

## Bibliografias

No plano tem uma lista de bibliografias recomendadas, mas para Arquitetura usaremos efetivamente as seguintes obras:

- FOWLER, Martin. **Padrões de Arquitetura de Aplicações Corporativas.** Editora Bookman.
- MPP Team. **Microsoft® Application Architecture Guide.** 2nd Edition (Patterns & Practices). Disponível para download em: <https://www.intertech.com/Downloads/eBook/ApplicationArchitectureGuide.pdf>
- ALUR, Deepak. **CORE J2EE Patterns: as melhores práticas e estratégias de design.** Editora Elsevier.

## Conteúdos

Todos os conteúdos teóricos escritos _on-the-fly_ na aula estão nos respectivos repositórios `aula-00-tema`. Os códigos também estarão nos mesmos repositórios.

## Atividades Avaliadas e Exercícios

As avaliações serão submetidas através da plataforma GitHub Classroom em <https://classroom.github.com/classrooms/40327509-aps-2018-2>. nos respectivos repositórios `atividade-00-tema`. Os estudantes deverão estar listados na organização <https://github.com/aps-2018-2>.

## Notas

As notas nas atividades e provas estão no arquivo <https://github.com/aps-2018-2/sobre/blob/master/NOTAS.md>.

