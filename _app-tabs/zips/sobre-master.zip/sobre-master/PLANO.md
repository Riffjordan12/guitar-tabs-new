![IFRS Rio Grande](http://www.cti.riogrande.ifrs.edu.br/sistemas/evento/templates/ifrs-2016/img/cabecalho.png)

# PLANO DE ENSINO

**Curso Superior de Tecnologia em Análise e Desenvolvimento de Sistemas (TADS)**

## Arquitetura e Projeto de Sistemas (APS-2018-2)

Carga horária: 120h | Semanas: 18 | Posição no QSL: 3º semestre

Período letivo: agosto de 2018 a dezembro de 2018 (2018-2)

Professor: Márcio Torres

Horário de atendimento: terça-feira das 14h às 16h e das 20h30 às 22h

## Ementa

Arquitetura de sistemas. Projeto de Objetos e Modelagem de Domínio. Princípios de Projeto Orientado a Objetos. Padrões de projeto. Biblioteca de classes, API, Frameworks e componentes de software. Camadas de persistência com uso de SGBDs e Mapeamento Objeto-Relacional. Ferramentas para teste de software. Desenvolvimento colaborativo de aplicações.

## Objetivos

Ao final dessa disciplina o estudante deve ser capaz de:

- Preparar um ambiente de desenvolvimento;
- Entender quando e onde usar padrões de arquitetura e projeto;
- Projetar a arquitetura de uma aplicação;
- Implementar bibliotecas e frameworks;
- Testar e avaliar a qualidade das soluções;

O estudante pode se apropriar das seguintes habilidades colaterais:

- Ler textos técnicos de tutoriais, manuais, livros e outras fontes;
- Escrever textos técnicos;
- Raciocinar logicamente para desenvolver algoritmos e resolver problemas;

Espera-se que o estudante desenvolva as seguintes atitudes:

- Ser cooperativo: aprender a trabalhar em equipe;
- Ser autodidata: aprender a aprender;
- Ser judicioso: aprender a fazer decisões difíceis;
- Ser austero: aprender a aceitar apenas os compromissos que pode cumprir;
- Ser resiliente: aprender a lidar com situações críticas;

## Conteúdo programático

- ARQUITETURA (Márcio)
  - Conceito e princípios de Arquitetura de Sistemas
  - SoC e as camadas principais
  - Interesses transversais (cross-cuting concerns)
  - Padrões de Arquitetura: layer supertype
  - Persistência: Data Access Object
  - Domain Logic: Transaction Script
  - Web: Model View Controller (MVC)
  - Front Controller
  - Lazy Load
  - View Helper
  - Intercepting Filter
  - Ferramental:
    - Eclipse
    - JUnit
    - SparkJava
    - SQLite, sqlitebrowser
    - Pebble
- PROJETO (Betito)
  - PADRÕES DE PROJETO
    - SINGLETON
    - ADAPTER
    - STRATEGY
    - COMMAND
    - ITERATOR
    - STATE
    - PROTOTYPE
    - PROXY
    - ADAPTER
  - Ferramental:
    - NetBeans
    - ‎PostgreSQL
    - ‎pgAdmin3

## Metodologia

- Aulas dialogadas com emprego de quadro, projeção de códigos-fonte, recursos audiovisuais, e exemplos práticos;
- Atividades em aula com a utilização de uma aplicação problema, resolvida com os padrões e princípios de arquitetura estudados;
- Atividades para resolução em casa (tema);
- Disponibilização de materiais, resumos, livros, artigos, exemplos extras e outros recursos sobre **ARQUITETURA** no site: <https://github.com/aps-2018-2/>

## Oportunidades de Integração Curricular

Possibilidade de integrar com as disciplinas de Desenvolvimento para Web I e Engenharia de Softwares, ambas no 3ro semestre e com possibilidade de aplicações.

## Avaliações

Serão feitos trabalhos práticos baseados na aplicação dos princípios e padrões abordados.

A composição da nota final se dará pela média de todas as atividades com peso 4 para Arquitetura (Márcio) e peso 6 para Projeto (Betito).

**Observações importantes:**

Quanto ao período:

Os pontos são contados no semestre inteiro, ou seja, ao final do semestre a nota final é cadastrada nos dois bimestres;

Quanto a adaptabilidade:

Os métodos, avaliações e a distribuição dos pesos podem variar conforme o andamento da turma;

Quanto a prazos:

Cada um é responsável pelas suas atividades [autodisciplina, austeridade]. Prazos não são estendidos, trabalhos entregues com atraso não são avaliados [austeridade]. Contudo, prazos podem ser pré-negociados.

Quanto a pontualidade e faltas:

Há uma tolerância de 10 minutos para iniciar a aula. Se, por exemplo, a aula é às 18h50, então às 19h faço a chamada, se ausente então fica com falta no primeiro horário. Os alunos que não conseguem chegar no horário, por trabalho ou outro motivo importante, devem acordar um horário comigo.

Quanto a equipamentos pessoais e softwares:

Aqueles que usam equipamentos próprios nas aulas (ex.: notebooks, netbooks, tablets, etc) são responsáveis por eles, ou seja, é obrigação do aluno ter os softwares instalados e configurados corretamente nos seus equipamentos pessoais. A primeira aula é destinada ao setup,inclusive dos equipamentos pessoais, após é necessário que a configuração seja realizada em horário de atendimento.

Quanto a recuperação paralela:

A disciplina é inerentemente prática, ou seja, pode ou não  ter prova teórica, dependendo do andamento das aulas. A recuperação paralela é prevista apenas para provas. Sendo assim, serão realizadas recuperações apenas quando forem aplicadas provas ou testes teóricos. Para atividades práticas, o tempo disponível dentro dos prazos será suficiente para retomar e assimilar os conhecimentos e habilidades necessários para sua resolução, seja por estudo próprio ou atendimento.

Quanto aos casos excepcionais:

Casos excepcionais são tratados com ambos profs. Márcio e Igor, e cada caso é um caso. Nestas situações vamos nos reunir e tomar medidas justas segundo nosso bom senso, recorrendo sempre que possível, e se necessário, ao apoio do coordenador do curso, coordenação pedagógica, secretaria, psicólogo(a) e/ou demais amparos fornecidos pelo instituto.

## Bibliografia

FREEMAN, Elisabeth. **Padrões de Projeto, da Série Use a Cabeça.** Editora Alta Books,2007

SHALLOWAY, Alan; TROTT, James. **Explicando Padrões de Projeto.** Bookman, 2004

GAMMA, E.; JOHNSON, R.; VLISSIDES, J.; HELM, R. **Padrões de Projeto: Soluções reutilizáveis de software orientado a objetos.** 1.ed. Editora: Bookman, 2000

FOWLER, Martin. **Padrões de Arquitetura de Aplicações Corporativas.** Editora Bookman.

FOWLER, Martin. **Catalog of Patterns of Enterprise Application Architecture.** Disponível em: <https://martinfowler.com/eaaCatalog/>

EVANS, Eric. **Domain Driven Design.** Alta Books.

MPP Team. **Microsoft® Application Architecture Guide.** 2nd Edition (Patterns & Practices). Disponível para download em: <https://www.intertech.com/Downloads/eBook/ApplicationArchitectureGuide.pdf>

CAELUM Team. **Introdução à Arquitetura e Design de Software: Uma visão sobre a plataforma Java.** Editora Casa do Código. Link: <https://www.casadocodigo.com.br/products/livro-arquitetura-java>

BUSCHMANN, Frank et.al. **Pattern-Oriented Software Architecture: a System of Patterns - Vol.1.** (EN) Editora Wiley.

ALUR, Deepak. **CORE J2EE Patterns: as melhores práticas e estratégias de design.** Editora Elsevier.

Sun Java2EE Team. **CORE J2EE Patterns Catalog Site.** Disponível em: <http://www.corej2eepatterns.com/>


## Softwares necessários e contas de usuário

- Sistema Operacional Microsoft Windows 7+ ou Ubuntu Linux 16.04+;
- Java Development Kit (JDK) 8+ (disponível em <https://goo.gl/SYyPpJ>);
- IDE Eclipse <http://www.eclipse.org/downloads> e NetBeans <http://netbeans.org/>;
- PostgreSQL 9+;
- SQLite;
- Conta de E-mail;
- Conta no GitHub <http://github.com> e inscrição na sala de aula <https://classroom.github.com/classrooms/40327509-aps-2018-2>;
- Inscrição no grupo do Slack <https://aps-2018-2.slack.com>: use este _invite link_ <https://join.slack.com/t/aps-2018-2/shared_invite/enQtNDA4MzQ2OTA0NjI3LWUzMzJjYmJjNWQxMzM0MGVjMGJkN2Q4MWE3ZmJlYWU4ZDRlMGU5YjM5YmFkZTQ4ZDM1NmNmNzQ2ZDRkNTlhZDQ>.


____________________________
Márcio Torres

____________________________
Rafael Betito
